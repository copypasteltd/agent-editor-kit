# 本机 GPU 扩展离线包与安装 / Native GPU extension delivery

[使用手册](COMMUNITY_MATERIALS.md) · [繁體中文](COMMUNITY_MATERIALS.zh-TW.md) · [English](COMMUNITY_MATERIALS.en.md)

当前本机版本是 **`v0.1.0-alpha.4-local.38` / CLI 0.1.40**，正式安装在 `E:/dev/sandbox/AI广告剪辑/local/agent-ffmpeg/v0.1.0-alpha.4-local.38/final-r1/installed/`。这是本地构建和验收记录；公开 GitHub Release 仍是 alpha.3 / CLI 0.1.2，原附件、标签和摘要不覆盖。

The current build is installed locally. Public alpha.3 downloads remain unchanged and do not contain the new voice, translation, material or GPU commands. The updated Skill kit must be paired with this matching local runtime bundle.

此前新增[可编辑广告分镜、多画幅/时长与指定镜头返工](AD_STORYBOARD.md)以及同语种原文 GPU 批量配音。此前的完整性读取超时/取消、[语义任务恢复](SEMANTIC_JOB_RECOVERY.md)、[语义工程包迁移](SEMANTIC_PROJECT_PACKAGE.md)、[显式条件与设备绑定的经验校准拒识](SEMANTIC_RETRIEVAL.md)、[字幕翻译配音联合流程](SUBTITLE_DUBBING.md)、[CTC 词活动边界](CTC_ACTIVITY_ALIGNMENT.md)、[原生任务恢复](JOB_RECOVERY.md)、[独立四轨分离](FOUR_STEM_SEPARATION.md)、[原生采集](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/product/NATIVE_CAPTURE.md)及精确声道关系修复继续保留。早期 `v0.1.0-alpha.4-local.1` 的 ZIP 与 SHA-256 `cf4e55f410582547d7fe56549d4594b4d8f0ee6aff8be24f77408c035fd74ead` 保留，旧 r2 kit 继续匹配旧包。

## 本机文件 / Local files

所有路径均位于 `E:/dev/sandbox/AI广告剪辑/` 下。

| 内容 / Item | 路径 / Path | 校验 / Verification |
|---|---|---|
| 编译好的基础运行 ZIP / Application bundle | `local/agent-ffmpeg/v0.1.0-alpha.4-local.38/candidate-r1/bundle.zip` | SHA-256 `c2448325021ec73c6dd182b9a9ffcb31df7e04e250ea3bc7826b57e653ece39a` |
| 运行包清单 / Bundle manifest | ZIP 内 / inside ZIP: `manifest.json` | `sha256:737f8b87d3aa95bd07cbc3323332ef1a18684e78407c7cae821f99f079f170c7` |
| 单入口 Skill kit / Single-entry kit | `docs/skills/agent-editor-kit-community-unified-skill-r41.zip` | [独立包摘要 / Package digest](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/skills/community-unified-skill-package-0.1.40-r41.json) |
| 四个模型 ZIP / Four model ZIPs | `local/agent-ffmpeg/community-model-archives-r2/` | 见下表及 / see table and `archives.json` |
| 可移动模型安装 / Relocated model installation | `local/agent-ffmpeg/community-portable-r1/模型 包/` | 实际从四个 ZIP 安装；路径含中文与空格 / actually installed from all four ZIPs |
| 当前调用配置 / Runtime configuration | `local/agent-ffmpeg/runtime.json` | 固定应用摘要、原生 Python、启动器摘要 / pinned app, native Python and launcher |
| CPU/GPU 路径配置 / Device configuration | `local/agent-ffmpeg/community-runtime.json` | 按任务指定 CPU/GPU 包及已有 NVIDIA DLL 目录 / explicit per-task pack/library paths |

基础运行包含 8 个固定 wheel、500 LUT 和 359 项真实音频/字体资源；模型权重分层存放，基础运行 ZIP 不含下面四个模型包。模型 ZIP 总计约 1.05 GB，展开约 1.34 GB。GPU 外部运行库另计；安装中不在 C 盘下载模型，不创建虚拟环境。

The application contains eight pinned wheels, 500 looks and 359 actual music/jingle/SFX/font files. Model weights remain optional and separate. The four model archives total about 1.05 GB, expanding to about 1.34 GB; existing external NVIDIA runtimes are separate.

| 包 ID / Pack ID | ZIP bytes | ZIP SHA-256 | Manifest SHA-256 |
|---|---:|---|---|
| `kokoro-zh-en-int8` | 151369628 | `1b970731deea9df5194c9ea6d9c072ee074c753ba5d0ee42f266c069ad1de553` | `5df1e69b62cb023489b131b238a765fec9581afc37fb21840fd3c3f77faaa29e` |
| `opus-zh-en-cpu-int8` | 150960451 | `65d045735deccb170f12d4db0df8fa0ad79b2c88d326fc00b004393958953e58` | `95d8b0953de8fb65cc93815d646a034c9a794226aff28f76b8693bf41d04c2be` |
| `kokoro-zh-en-cuda13` | 583062292 | `87bc0691310db90a9d1cda9992d869089dfe73ea2331d988683e7457e02dfa08` | `fb46a9cfc9823f4cb18d1c669a145e2fec772e39e0e32f1a7a68eae18cc4d987` |
| `opus-zh-en-cuda12-int8` | 168635396 | `35084c7c17093f62bf0aff6479d1c67d4c11860bdae88238e89f584441c82d0f` | `eda65efa7fa83be5f1bd01dab3c5b6278aaa897cd747d82549b135f74a0838d4` |

## 从本地包安装到新目录 / Install supplied local archives

要求原生 Windows x64、已有 CPython 3.13 x64、FFmpeg/ffprobe 在 PATH。包和输出目录必须是本地路径；不使用 Docker、WSL、容器、虚拟环境、全局 pip 或隐式下载。准备好上述 ZIP 后执行；示例目录需尚不存在。`$aekSource` 按收到的本地交付位置调整。

Requires native Windows x64, existing CPython 3.13 x64 and FFmpeg/ffprobe on PATH. Supply the local archives first. Choose a new destination; no global installation or network access is used.

```powershell
$aekPython = 'C:/Python313/python.exe'
$aekSource = 'E:/dev/sandbox/AI广告剪辑'
$aekHome = 'E:/tools/agent-editor-kit-gpu'
$aekArchive = Join-Path $aekSource 'local/agent-ffmpeg/v0.1.0-alpha.4-local.38/candidate-r1/bundle.zip'
$aekExpectedZip = 'c2448325021ec73c6dd182b9a9ffcb31df7e04e250ea3bc7826b57e653ece39a'
if ((Get-FileHash -LiteralPath $aekArchive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $aekExpectedZip) { throw 'Application archive hash mismatch' }
Expand-Archive -LiteralPath (Join-Path $aekSource 'docs/skills/agent-editor-kit-community-unified-skill-r41.zip') -DestinationPath $aekHome
Expand-Archive -LiteralPath $aekArchive -DestinationPath (Join-Path $aekHome 'bundle')
Set-Location $aekHome
& $aekPython -I -B -X utf8 ./bundle/install.py --bundle ./bundle --target ./local/agent-ffmpeg/installed --manifest-sha256 'sha256:737f8b87d3aa95bd07cbc3323332ef1a18684e78407c7cae821f99f079f170c7' --timeout-seconds 600
if ($LASTEXITCODE) { throw 'Native application installation failed' }
```

逐个安装需要的模型包；配音和翻译分别需要自己的 CPU 包，GPU 包为可选加速。下例安装全部四包，输入清单来自实际 ZIP 摘要；安装器另检查安装版 CLI 内置的模型清单 pin、ZIP 文件集和每个解压文件。它拒绝已有目标、错误摘要、额外/缺失文件和内容改动，并清理本次失败的 staging。

Install the needed CPU packs and optional CUDA packs. The following installs all four from the supplied archives, verifying both archive digests and the installed application's manifest pins.

```powershell
$aekModelArchives = Join-Path $aekSource 'local/agent-ffmpeg/community-model-archives-r2'
$aekPacks = Join-Path $aekHome 'local/agent-ffmpeg/models'
New-Item -ItemType Directory -Path $aekPacks -Force | Out-Null
$aekCatalog = Join-Path $aekHome 'local/agent-ffmpeg/installed/site/ai_ad_editor/material_data/model-packs.json'
$aekPackRows = (Get-Content -LiteralPath (Join-Path $aekModelArchives 'archives.json') -Raw -Encoding utf8 | ConvertFrom-Json).packs
foreach ($aekPack in $aekPackRows) {
    & $aekPython -I -B -X utf8 ./scripts/install_community_pack.py --archive (Join-Path $aekModelArchives ($aekPack.id + '.zip')) --sha256 $aekPack.sha256 --catalog $aekCatalog --id $aekPack.id --target (Join-Path $aekPacks $aekPack.id)
    if ($LASTEXITCODE) { throw ('Model installation failed: ' + $aekPack.id) }
}
```

将已有 NVIDIA 库路径改为本机实际位置。配音需要 CUDA 13/cuDNN 9；翻译需要 CUDA 12 cuBLAS，两者可来自不同的已安装目录。不会启动这些库所属的其他软件。无 GPU 时省略下面两个 library 参数即可保留 CPU 方案。

Use actual existing NVIDIA library directories. Voice needs CUDA 13/cuDNN 9; translation uses CUDA 12 cuBLAS. Their directories may differ. No associated server/application is started. For CPU-only operation omit the two library arguments.

```powershell
$aekVoiceCuda = 'E:/libraries/cuda13-cudnn9/bin'
$aekTranslationCuda = 'C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v12.4/bin'
& $aekPython -I -B -X utf8 ./scripts/activate_community_runtime.py --installed ./local/agent-ffmpeg/installed --packs $aekPacks --voice-cuda-lib $aekVoiceCuda --translation-cuda-lib $aekTranslationCuda
if ($LASTEXITCODE) { throw 'Runtime configuration failed' }
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ./register-agent-ffmpeg-local-skills.ps1
if ($LASTEXITCODE) { throw 'Skill registration failed; preserve an unrelated existing registration' }
$avk = Join-Path $aekHome 'skills/agent-ffmpeg-local-editor/scripts/run.ps1'
& $avk version
& $avk gpu inspect
& $avk capabilities
& $avk voice list
```

注册器只处理本项目拥有的目录联接；同名但无关的注册会保留并报错。已使用当前仓库入口时无需另注册到另一个安装目录。客户端缓存未刷新时重新打开会话，外层继续只指定 **`$agent-ffmpeg-local-editor`**。

The registrar preserves unrelated same-name registrations. Existing users may keep this repository's registration. Refresh the client/session discovery cache when necessary; use one Skill entry.

模型包逐个做完整性校验，每包默认期限为 600 秒；大模型正在读盘或磁盘较慢时，可显式向 `activate_community_runtime.py` 传入 `--verify-timeout-seconds 1200`（范围 1–3600）。达到期限时保存失败记录并保留此前的运行配置，不会跳过摘要校验。

Each model pack has a 600-second verification deadline. During heavy local I/O, pass `--verify-timeout-seconds 1200` to `activate_community_runtime.py` (range 1–3600). Timeout retains a failure receipt and the previous runtime configuration; integrity checks are never skipped.

## 设备选择与许可 / Device selection and terms

- `--device auto` 默认优先可用 GPU，配音预检 3072 MiB、翻译 1536 MiB 空闲显存；返回实际设备和回退原因。
- `--device cuda` 严格使用 GPU，依赖、显存或推理失败时返回失败；`--device cpu` 强制 CPU。
- RTX 3060 已实际测试；不承诺 AMD/Intel/Apple GPU，亦不承诺单次冷启动更快。不会停止其他 GPU 任务。
- 核心、模型、素材和可选数值库分别保留许可。GPU 翻译包保留 `GPU-DEPENDENCIES.txt`、Intel OpenMP/MKL 和 oneDNN 原始许可；NVIDIA 系统库不随包再分发。独立 CPU Ruy 翻译包不含 MKL/Intel OpenMP/CUDA 后端。
- `auto` prefers an available GPU and reports fallback; `cuda` is strict; `cpu` is explicit. Optional NVIDIA/Intel terms do not replace open-source engine/model/media licenses.

## 原始核验 / Evidence

[本轮 CPU](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/evidence/community-materials-20261025-r1/cpu/verification.json) · [GPU](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/evidence/community-materials-20261025-r1/gpu/verification.json) · [可移动安装与拒绝](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/evidence/community-materials-20261025-r1/portable/verification.json) · [单入口实际调用](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/evidence/community-materials-20261025-r1/skill/verification.json) · [验收与未完成项](COMMUNITY_ACCEPTANCE.md)。

这些记录区分真实生成、解码、静态目检、连续播放和人类听审。不把三音色生成或 103 条映射当成全部音色的质量验收。


## CLI 0.1.5 离线图文语义检索 / Offline visual semantic retrieval

[完整使用流程](SEMANTIC_RETRIEVAL.md) · [本轮完整实测](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/离线语义检索实测_2026-10-25.md)。
CLI 0.1.5 开始交付该检索功能；对应旧包与[当时安装记录](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/evidence/semantic-20261025-r1/installation/verification.json)保留。
CLI 0.1.7 当时的基础 ZIP 为 302,628,548 字节；8 wheel、清单登记 47 文件，连同 manifest.json 共 48 个 ZIP 文件；产品 wheel 为 0.1.7。
194 个产品 Python 文件与安装版逐字节相同；[本次安装审计](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/evidence/job-recovery-20261025-r1/installation/verification.json)。
同一 RTX 3060 主机验证 CUDA BF16 和 CPU float32。Torch/Transformers 及约 1.5GB SigLIP2 权重
单独来自既有原生环境，不在基础 ZIP 或四个配音/翻译 ZIP 内；产品不隐式安装或下载。

现有工作区的 `local/agent-ffmpeg/semantic-runtime.json` 记录本机绝对路径、模型摘要和许可依据，
`runtime.json` 的 `semantic_config` 指向该文件。Agent 对新工程仍须明确 `semantic adapter-register`。
换主机应创建包含实际 `python_executable`、`model_path`、`evidence`、`creator`、`license_spdx`、
`verification_status` 与 `format: agent-local-semantic-runtime-v1` 的本地 JSON，再传给激活脚本；
不得复制不可用的绝对路径，登记时由产品重新检查依赖和字节。

```powershell
# The JSON and all referenced native paths must already exist.
& $aekPython -I -B -X utf8 ./scripts/activate_community_runtime.py --installed ./local/agent-ffmpeg/installed --packs $aekPacks --voice-cuda-lib $aekVoiceCuda --translation-cuda-lib $aekTranslationCuda --semantic-config $aekSemanticProfile
```

This optional profile supports explicit registration; it does not activate model inference or download files.
The base archive and four speech/translation packs remain separate. Clean-host acceptance is still open.

历史 CLI 0.1.4 / local.2：
`local/agent-ffmpeg/v0.1.0-alpha.4-local.2/agent-editor-kit-v0.1.0-alpha.4-local.2-cp313-win_amd64.zip`，
SHA-256 `4e406058e082d1c9d778e9c4665f307d5027f17542c6fabfbc9d8d72ac0a2333`，
manifest `sha256:fd418d94461b57423072fb730959e36cb39264fd48a96be26dc297fe52b59897`；
[r3 kit](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/skills/agent-editor-kit-community-unified-skill-r3.zip) 继续对应旧包，旧标签/附件未改。


## CLI 0.1.6 独立四轨 / Independent four-source separation

[登记、设备选择、信号契约与完整命令](FOUR_STEM_SEPARATION.md) · [真实 CPU/GPU、安装版与 Skill 实测](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/独立四轨音源分离实测_2026-10-25.md)。
`audio separate-stems` 保存 drums/bass/other/vocals 四个独立模型预测，`--apply` 新建四条可编辑音轨；
auto 优先 NVIDIA，严格 CUDA 和 CPU 路径分别返回实际设备。新的音频 adapter 明确使用
`torchaudio-hdemucs-four-stem-local-v1`；不能将既有双轨 adapter 当成四轨 adapter。

该功能需另供原生 Python/Torch/TorchAudio/NumPy 与兼容 checkpoint，**不在上述四个 Kokoro/OPUS 模型包内**。
本机实验权重权利仍为 unverified，不随包再分发；基本 ZIP 与小型 Skill kit 均不含 Torch 或四轨权重。
受控样例通过不等于自然音乐/去混响/人工听感已经验收。

### 升级时重新固定路径 / Explicit upgrade pins

旧 local.3 / CLI 0.1.5 的 ZIP SHA-256 为 `804cac8e45d62b4440fb39423126a86d650e415e37ed3f9b7db724b65a2a62cd`，
manifest `sha256:29583211d5cf376f51c295b419ba7bdaaf9f46fa5314820fcc6e180f47a4f95f`；
[r4 kit](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/skills/agent-editor-kit-community-unified-skill-r4.zip) 与旧包继续保留。
升级请选择新目录，核对实际 version/manifest 后显式激活。模型 adapter 和检索索引固定实现的绝对路径及摘要；
换安装路径后需要明确重登记相应 adapter，语义索引按其绑定实现重新建立/验证，不能默认复用旧 pin 或修改旧证据。
原始素材、旧安装和工程快照保留；尚未完成另一台干净物理主机的升级/回滚验收。

The new runtime preserves historical bundles. Register model adapters explicitly against the actual installed implementation;
rebuild/verify path-pinned semantic indexes when the implementation installation changes. No silent source fallback,
model download or adapter migration is performed. Independent four-source weights/native dependencies remain separate,
and clean-host upgrade/rollback acceptance is open.

## CLI 0.1.7 原生中断恢复 / Native interruption recovery

[完整使用与保留规则](JOB_RECOVERY.md) · [真实故障注入、回归与成片](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/任务中断恢复实测_2026-10-25.md)。
新四轨任务持久化工作目录和输出意图，正常提交/回滚后清理；强制结束后先预览再执行
`project recover --cleanup-jobs`。默认 `project recover` 仍只恢复元数据。此功能不删除旧非管理缓存，
不提供模型断点续算，也不代表完整 G33 已关闭。

旧 local.4 / CLI 0.1.6：`local/agent-ffmpeg/v0.1.0-alpha.4-local.4/candidate-r2/bundle.zip`，
SHA-256 `10ec4f490186f3f0c34ae52921aec0e8fd76e302d89252449b4e1651b68ecc71`，
manifest `sha256:8206db8867a0d0908153cfa00f425c469909fb07545102ec59dcdc8e007b5ba9`，
[r5 kit](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/skills/agent-editor-kit-community-unified-skill-r5.zip) 仍匹配旧包；历史核验原样保留。
四轨完整性固定项由 8 个实现文件增为 12 个（加模型/Python/证据共 15 项），请明确重新登记 adapter。

The historical r6 kit contains one Skill and 17 internal modules, with a recovery reference and this matching
runtime pin. Native lifetime tests, real installed hard-stop boundaries, normal CPU/GPU inference and
editable delivery are recorded separately. Older unmanaged caches and historical evidence remain intact.


## CLI 0.1.8 词活动边界 / CTC word-boundary extension

[完整使用流程与限制](CTC_ACTIVITY_ALIGNMENT.md)。显式 `--boundary-mode activity` 使用同一 PCM，
保留原 CTC 字符/词时间，控制器独立重算区间与决定。默认 `ctc` 语义保持。
这是另行登记的已有原生 Torch/Transformers 与 Wav2Vec2ForCTC safetensors，
**不在基础 ZIP 或四个 Kokoro/OPUS 包内**。CPU/CUDA 显式选择，不隐式下载或回退。
受控词块精度改善不代表自然连续语音、中文、歌词或重叠声音验收完成。

CLI 0.1.8 历史包实际 8 wheel / 195 个产品 Python 文件，全部与源码逐字节一致：
[固定安装审计](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/evidence/ctc-activity-20261025-r1/installation/verification.json)。
未完成另一台干净原生主机安装；未新建公开 Release。
开发 candidate-r2 属于 v2 失败候选，保留且未激活；该历史交付匹配 local.6/candidate-r2 的 v3 摘要；本页上表现已指向条件检索 local.8 的新摘要。

历史 local.5 / CLI 0.1.7 与 r6 kit 保留：
ZIP SHA-256 `12f0d076f1b0dd18f7438adf678a99354a0ce6fa1b10843f326ebc2a8d8251da`，
manifest `sha256:ae4daffd658d326df75d1b8c0540a3f193800f03528d0d38883a0767f73fa5a0`；
[r6 kit](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/skills/agent-editor-kit-community-unified-skill-r6.zip) 与其固定的旧安装仍可复现，未被覆盖。


## CLI 0.1.9 历史字幕翻译配音联合流程 / Joint subtitle dubbing

[完整使用流程](SUBTITLE_DUBBING.md) · [实际 CPU/GPU/Skill、故障与成片](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/字幕翻译配音联合流程实测_2026-10-25.md)。
复用上表四个既有模型包，不新增下载；一次 voice batch 初始化一次 Kokoro。
按实际完整 WAV 检查原 cue 时窗，明确目标 audio/subtitle 轨道后原子应用；超窗拒绝或显式完整再生成。
普通 SRT / 中英；语义、自然听感、精确字词和口型仍未验收，实际不自然译文保留。

该历史版本 ZIP 302,645,253 bytes，8 wheel；manifest 登记 47 文件，含自身共 48 ZIP 文件。
该版本当时 197 个产品 Python 文件等于最终源码：[新安装审计](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/evidence/subtitle-dubbing-20261025-r1/installation-r2/verification.json)。
最终安装版 27 项新专项和 122 项 CLI 回归通过；新 r8 kit 仍是一个入口/17 内部模块。
不代表干净主机验收，不覆盖旧公开 Release。

旧 local.6 / CLI 0.1.8 和 r7 kit 保留：
ZIP SHA-256 `a5c6f773e32122347b36ba471b5f8c28fe0fe422cd20d69d4c8a6ad96202182e`，
manifest `sha256:8aae41452002706b2c74398c1e58fc7c16db458932e62f3e3614b57248d7994a`；
[r7 kit](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/skills/agent-editor-kit-community-unified-skill-r7.zip) 与旧运行 pin 不改。
本批 local.7/candidate-r2 的模型字典处理错误已留档，未激活；该历史安装只使用 local.7/candidate-r2 摘要；上表现已指向 local.8/candidate-r2。


## CLI 0.1.12 历史语义任务恢复 / Managed semantic recovery

302663151 bytes、202 个产品 Python 文件；[完整实测](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/语义任务中断恢复实测_2026-10-25.md)。
7 类真实故障/清理核验；1 秒超时存在同步校验延后，未关闭完整 G32/G33。旧 local.9/r10 和全部历史证据保留。

## CLI 0.1.11 语义工程包迁移 / Semantic project-package migration

应用 ZIP 302,659,130 bytes，200 产品 Python 文件；[安装收据](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/evidence/semantic-package-20261025-r1/installation-r1/verification.json)。
[使用流程](SEMANTIC_PROJECT_PACKAGE.md) · [完整实际核验](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/语义工程包迁移实测_2026-10-25.md)。
CPU/CUDA/统一 Skill 各 80 条迁移后查询保持原决策；两条误接受和一条钟表误拒仍在。
外部模型、原生运行时和安装实现 pin 保留；不是干净主机交付或全部 G31 关闭。
旧 local.8 / CLI 0.1.10、r9 kit 与 C19 原错误保留；下节是当时历史实测。

## CLI 0.1.10 条件检索与经验拒识 / Explicit clauses and calibrated decisions

[完整操作流程](SEMANTIC_RETRIEVAL.md) · [实际模型/失败/安装/Skill/案例](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/语义条件与校准拒识实测_2026-10-25.md)。

新运行 ZIP 302,655,012 bytes；199 个产品 Python 文件与源码逐字节一致，
[独立安装收据](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/evidence/semantic-decision-20261025-r1/installation-r1/verification.json)。
最终源码和安装版检索专项分别 48/48；安装版完整 CLI 122/122、0 skip。
原始整句排名继续用 `--query-mode raw` 复现，默认条件查询配合索引/类型/实际设备绑定的
经验校准档案。该档案不证明通用拒识、自然动作/身份/音频推荐或完整 G26 关闭。

CLI 0.1.10 当时已实测的迁移缺口：新检索/校准工程 export/import/通用 validate 成功后，search dry-run
报 `SEMANTIC_INDEX_INVALID` / `Manifest outside project semantic asset tree`。
[C19 原错误与复现包](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/assets/semantic-decision-20261025-r1/demo-installed-r1/KNOWN_ISSUE.md)保留；
普通卡片工程的 360 帧往返通过不代替索引/档案可搬迁或干净主机验收。

Torch/Transformers 与 SigLIP2 权重仍为另行登记的既有本地依赖，不在本应用 ZIP 或四个
Kokoro/OPUS 包内。语义实现内容改变须重新登记并重建。仅安装位置改变且 19 个实现与外部依赖字节相同时，可用
`project upgrade-semantic` 显式派生新绑定，不重新推理；不能手改原 pin。单一注册 Skill 和内部模块数保持 1/17；公开旧 Release 不覆盖。

历史 local.7 / CLI 0.1.9 与 r8 kit 保留：ZIP SHA-256
`d085f6109a73d0e92ce9f160c1dab68925c21a5775a9d8ec7d8a710e14cc456d`，
manifest `sha256:0a79580cc12c1ec813404f3838fa2f17dc0c8d4a67678e4b25fba88d870facfe`；
[r8 kit](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/skills/agent-editor-kit-community-unified-skill-r8.zip) 与其旧 pin 不改。

## CLI 0.1.13 历史交付 / Historical delivery

302664913 bytes、203 个产品 Python 文件；[读取超时/取消实际核验](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/完整性校验超时取消实测_2026-10-25.md)。旧 local.10/r11 与原收据保留。CPU/CUDA 和统一入口验证按本批收据记录；模型仍逐命令加载，完整 G32/G33 未关闭。

## CLI 0.1.14 历史交付 / Historical delivery

302674843 bytes、205 个产品 Python 文件。新增[可编辑广告分镜/变体/返工](AD_STORYBOARD.md)和保留原文的同语种批量 GPU 配音；[实际案例、失败和边界](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/可编辑广告分镜与返工实测_2026-10-25.md)。旧 local.11/r12 和候选 r1 收据保留。公开仍 alpha.3；自然质量和完整原目标继续开放。

## CLI 0.1.15 历史交付 / Historical delivery

302681558 bytes、206 个产品 Python 文件。[显式语义运行时升级](SEMANTIC_RUNTIME_UPGRADE.md)允许相同实现/依赖在安装路径变化后复用向量、预览和设备校准；旧记录/资产/权利保留，零新模型前向。原 0.1.14/local.12/r13 包和原始失败保留，模型路径或字节不兼容时仍拒绝。[真实实测](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/语义运行时升级实测_2026-10-25.md)。

## CLI 0.1.16 历史交付 / Historical delivery

302692612 bytes、208 个产品 Python 文件。新增[可复用运镜包](MOTION_PACKS.md)：六套参数化路径、已有关键帧捕获、明确属性冲突和作者时钟、工程包复用。[六套真实 MP4/GIF 与安装/Skill 实测](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/可复用运镜包实测_2026-10-25.md)。无模型推理或新依赖；变换仍为 CPU，NVENC 只加速编码。原 local.13/r14 与历史结果保留，全部完整目标继续进行。

最终候选 r2 补齐捕获/查询幂等键拒绝和负增量缩放边界；最终匹配 r16 kit。r1 候选与 r15 kit/首次测试及媒体记录均保留。默认六包和渲染实现保持，最终安装/Skill 重新核验；这不增加自然质量通过结论。

## CLI 0.1.17 历史交付 / Historical delivery

302693554 bytes，208 个产品 Python 文件。固定画布仿射合成自动按扫描行复用纯数值变换，浮点预乘双线性采样保持。[使用与实测预览](AFFINE_RENDERING.md) · [交错计时、逐帧与安装核验](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/仿射扫描行复用实测_2026-10-25.md)。CPU 计算优化，GPU 编码依旧显式选择；原 local.14/r16 和历史失败保留，全部完整目标继续推进。

## CLI 0.1.18 中间构建 / Intermediate build

动态裁切和子序列 crop/fit/TRS 复用行参数，双线性与面积采样精度保持。208个产品Python文件，基础ZIP 302695912 bytes。[完整使用流程](PROJECTION_RENDERING.md) · [安装核验](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/evidence/projection-scanline-20261026-r1/installation-r1/verification.json)。GPU只承担显式编码，完整目标仍开放。

## CLI 0.1.19 历史交付 / Historical delivery

最终面积积分复用上下边界，保留中间0.1.18包与主动中断证据。208产品Python文件，ZIP 302696007 bytes。[使用流程](PROJECTION_RENDERING.md) · [固定安装](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/evidence/projection-scanline-20261026-r1/installation-final-r1/verification.json)。模型、画质和投影配额保持，完整目标继续推进。

## CLI0.1.26 历史交付 / Historical delivery

219产品Python文件，73个Skill文件、17模块、r27独立kit。原生OpenCL crop/affine/sequence双线性/面积投影；CPU默认，GPU策略/配额/实际探测独立于编码。完整使用及队列/失败/恢复边界见 [GPU workflow](OPENCL_PROJECTION.md)，实际包摘要见 [固定交付](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/releases/CLI_0.1.26_LOCAL.md)。

2026-10-26：CLI0.1.26 已安装线性浮点转场/真实句柄/关联音轨/组级空间进出场；[完整使用与实际案例](FLOAT_TRANSITIONS.md)，[219文件固定离线交付](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/releases/CLI_0.1.26_LOCAL.md)。CPU浮点路径与既有GPU投影、GPU语音/翻译分别选择。旧包和全部原关闭条件保留。

当前新增[线性浮点文字、打字机/逐词高亮、SRT及原作者时钟](FLOAT_TEXT.md)。CPU字形合成与现有GPU投影、语音/翻译分别选择；字形覆盖率8位、颜色Float32。

当前[4K文字、原生字节覆盖率复用与分块合成](FLOAT_TEXT_COVERAGE.md)保留作者时钟及精度。当前可显式选择GPU字色合成，字形栅格仍在CPU；准入估算非峰值RSS或实时承诺。

当前[原生浮点GPU执行层](FLOAT_GPU.md)支持仿射、普通叠加、字色和逐词选择；实际设备/探测/取消清理均保留。其余算子与完整目标边界见契约。

当前新增 [Float32全局/区间调整层](FLOAT_ADJUSTMENTS.md)：按完整合成结果调色，选中根只应用一次，LUT依赖持锁并可移植；与已有GPU合成共存。

CLI0.1.26 历史新增 [原生PTS跟踪绑定与叠加轨](FLOAT_TRACKING.md)：动态观测、实际视频时钟/几何、嵌套声音；219产品文件、73 Skill文件、1入口/17模块。

## CLI0.1.27 历史交付 / Historical delivery

220产品Python文件，73 Skill文件、17模块、r28 kit。[跟踪后的可编辑剪辑](TRACKING_EDITS.md)补齐保留源分片、基准时钟和删除隐藏；[完整安装与实测](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/releases/CLI_0.1.27_LOCAL.md)。旧包、反例和38原关闭条件保留。

CLI0.1.28/local.26/r29：tracked physical slip/extension and rational constant clocks; [full workflow](TRACKING_SOURCE_EDITS.md), [verified release](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/releases/CLI_0.1.28_LOCAL.md). Earlier local versions remain historical.

CLI0.1.29/local.27/r30：native magnetic synchronized tracking cuts/reorder; [workflow](TRACKING_MAGNETIC.md), [verified local release](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/releases/CLI_0.1.29_LOCAL.md). Previous versioned records remain historical.

历史 / Historical：CLI0.1.30/local.28/r31：[shared-author tracking retime](TRACKING_RETIME.md), [verified local delivery](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/releases/CLI_0.1.30_LOCAL.md).

历史 / Historical：CLI0.1.31/local.29/r32：[实际跟踪可见度](TRACKING_VISIBILITY.md) · [verified local delivery](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/releases/CLI_0.1.31_LOCAL.md). 前版本[CLI0.1.30](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/releases/CLI_0.1.30_LOCAL.md)保留。

Historical / 历史：CLI0.1.32/local.30/r33：[原生跟踪烘焙](TRACKING_BAKE.md) · [verified local delivery](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/releases/CLI_0.1.32_LOCAL.md)。历史[CLI0.1.31](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/releases/CLI_0.1.31_LOCAL.md)保留。

CLI0.1.33/local.31/r34：[GPU生成流程](VIDEO_GENERATION.md) · [版本/摘要](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/releases/CLI_0.1.33_LOCAL.md)。VACE大权重与已有原生Torch/Diffusers运行时独立登记，不包含在四个配音/翻译模型包中。

CLI0.1.34/local.32/r35：[原生GPU模型会话](MODEL_SESSIONS.md) · [当前安装摘要](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/releases/CLI_0.1.34_LOCAL.md)。新增启动/状态/停止和生成复用；首次全模型校验及首次加载费用单独记录。

CLI0.1.35/local.33/r36 adds [editable procedural particles](PROCEDURAL_PARTICLES.md); see [C45](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/product/CASES.md#c45-procedural-particles) and [current installation hashes](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/releases/CLI_0.1.35_LOCAL.md).

CLI0.1.36/local.34/r37: [owned GPU control pipes](GPU_DISPATCH.md), [C46 timing and identical output](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/product/CASES.md#c46-gpu-dispatch), [local installation](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/releases/CLI_0.1.36_LOCAL.md).

CLI0.1.37/local.35/r38: [emitter keyframes](EMITTER_ANIMATION.md), [C47 actual editable output](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/product/CASES.md#c47-emitter-animation), [local installation](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/releases/CLI_0.1.37_LOCAL.md).

CLI0.1.38/local.36/r39: [optical effects](OPTICAL_EFFECTS.md), [C48 actual editable output](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/product/CASES.md#c48-optical-effects), [local installation](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/releases/CLI_0.1.38_LOCAL.md).

CLI0.1.39/local.37/r40: [highlight Bloom and Halation](HIGHLIGHT_GLOW.md), [C49 actual editable output](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/product/CASES.md#c49-highlight-glow), [local installation](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/releases/CLI_0.1.39_LOCAL.md).

CLI0.1.40/local.38/r41: [native PQ/HLG and SDR viewing](HDR_DISPLAY.md), [C50](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/product/CASES.md#c50-native-hdr), [installation](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/releases/CLI_0.1.40_LOCAL.md).
