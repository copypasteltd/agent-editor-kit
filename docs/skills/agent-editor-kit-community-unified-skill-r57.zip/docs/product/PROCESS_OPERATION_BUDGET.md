# 原生子进程继承命令预算（源码CLI55）

CLI55修复 `run_process` 等待期间没有检查外层 `operation_budget` 的缺口。改动覆盖实际使用这个公共辅助函数、且处于命令预算上下文中的调用；不宣称所有独立GPU控制管道都因此获得相同机制。

## 实际问题与行为

原来完整性读会检查外层期限，但等待子进程时只看显式子进程超时和显式取消文件。因此外层期限已过，子进程仍可能继续；仅在返回后再次检查时才报错，或者没有后续检查便返回成功。

修复后，启动前、读取线程等待循环和返回前都检查当前继承的预算。嵌套预算仍取更严格的外层条件；外层相对取消文件由其所属工程根目录解析，即使没有传给子进程辅助函数也会生效。等待期间中断会关闭本次自有Windows Job、停止自有进程树、等待读取线程回收，再保留原始取消／超时代码。不会结束其他GPU任务或进程。

这是合作式控制：不保证抢占操作系统阻塞调用，也不承诺0.2秒预算等于0.2秒硬实时终止。进程创建、轮询和资源回收有开销。

## 原生证据

| 编号 | 实际执行 | 结果 |
| --- | --- | --- |
| B01 | 旧CLI54逻辑：外层0.2秒，子进程10秒，原生子进程睡眠2秒 | [约2.217秒后仍成功完成](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/evidence/ad-selection-20261029-r1/nested-deadline-reproduction-r1/verification.json)，缺口复现 |
| B02 | CLI55相同原生场景 | [约0.373秒返回PROCESS_TIMEOUT](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/evidence/process-budget-20261029-r1/native-probe-r1/verification.json)，未返回完成结果；该时长不是性能保证 |
| B03 | 4项新增真实进程回归＋11项既有控制回归 | [15项通过](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/evidence/process-budget-20261029-r1/deadline-r1/verification.json)：继承更短期限、未直接传递的相对取消文件、过期后拒绝启动、原有子进程超时，以及实际PID／读取线程回收 |
| B04 | CLI55广告选材／分镜兼容 | [45项通过](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/evidence/process-budget-20261029-r1/selection-r1/verification.json)，部分CLI单元测试模拟语义服务，不是实际GPU选材 |
| B05 | CLI55语义／决策／任务／包／升级兼容 | [104项通过](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/evidence/process-budget-20261029-r1/semantic-r1/verification.json)；与15／45分别记录，281源码模块前后冻结一致 |

## GPU选材失败与新交付边界

CLI54真实 `ad select` 尝试在原生依赖加载阶段超时，未生成选中计划、未渲染：[原始失败](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/evidence/ad-selection-20261029-r1/case-r2/terminal.json)。不能将此前45／104单元测试或11素材索引／校准成功替代选材成片验收。

CLI54完整候选安装和93文件Skill候选保留作历史证据，没有激活。正式注册仍为CLI53／local51／r54。CLI55离线包和新原生GPU流程正在独立验证。

`utils.py` 属于语义适配器的19项实现绑定，修复后不能手工把旧索引／档案摘要改成新版。新流程在独立工程中重新注册适配器、索引完整11素材并校准；固定查询、标签、原始校准集和许可保持原样。完整冷启动延迟、真实选材、多画幅成片、完整音画重放、安装版和统一Skill仍需实际终态。

原38项产品关闭条件保留，尤其[G26／G27／G35及完整清单](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/product/GOAL_GAPS_20261025.md)。本修复不等于自然语义、独立Agent任务成功率或剪映全功能等价验收。

## 当前候选交付进度

[CLI55完整候选](https://github.com/copypasteltd/agent-editor-kit/blob/main/docs/validation/CLI55原生交付_2026-10-29.md)已实际离线安装，281模块／8原生资源一致；安装15／45／104分组各自通过。55版统一Skill候选PowerShell入口已实际核验（1入口／17模块／93文件），尚未注册；正式入口仍53／r54。GPU整链路保持原11素材和固定查询，分别验证D盘既有环境与另一套E盘既有原生环境；任何候选输出都需实际终态。
